﻿using LessonMVVM.Services;

namespace LessonMVVM.ViewModels.WindowViewModels;

public class MainViewModel : NotificationService
{
}
