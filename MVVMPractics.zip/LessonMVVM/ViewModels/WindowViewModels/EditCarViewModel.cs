﻿using LessonMVVM.Commands;
using LessonMVVM.Models;
using LessonMVVM.Services;
using MaterialDesignThemes.Wpf;
using System.Windows.Input;

namespace LessonMVVM.ViewModels.WindowViewModels;

public class EditCarViewModel:NotificationService
{


    private Car? car1;
    private Car? editCar;

    public Car? Gelencar { get => car1; set { car1 = value; OnPropertyChanged(); } }


    public Car? EditCar { get => editCar; set {editCar = value; OnPropertyChanged(); } }
    public ICommand?  SaveCommand { get; set; }
    public ICommand? CloseCommand { get; set; }
    public EditCarViewModel(Car? car)
    {
        this.Gelencar = car;

        EditCar = new Car(Gelencar?.Make, Gelencar?.Model, Gelencar?.Date);

        SaveCommand = new RelayCommand(SaveEdit);
        CloseCommand = new RelayCommand(CloseEdit);
    }

    public void SaveEdit ( object? parameter)
    {
        Gelencar.Make = EditCar?.Make;
        Gelencar.Model = EditCar?.Model;
        Gelencar.Date = EditCar?.Date;
    }

    public void CloseEdit (object? parameter)
    {
        Gelencar.Make.Clone();
        Gelencar.Model.Clone();
      

    }
}
