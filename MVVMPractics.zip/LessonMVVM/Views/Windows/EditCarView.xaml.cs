﻿using System.Windows;

namespace LessonMVVM.Views.Windows;


public partial class EditCarView : Window
{
    public EditCarView()
    {
        InitializeComponent();
    }
}
