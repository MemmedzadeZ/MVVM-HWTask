﻿using LessonMVVM.ViewModels.PageViewModels;
using System.Windows;

namespace LessonMVVM.Views.Windows;

public partial class AllCarView : Window
{
    public AllCarView()
    {
        InitializeComponent();
        //DataContext = new DashboardPageViewModel();
    }
}
